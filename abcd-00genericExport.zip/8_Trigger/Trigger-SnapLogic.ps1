﻿<#
.SYNOPSIS
	Triggers a Snaplogic Task passing a JSON object.
	Installs database components when task is 'Install-DB-Objects'.
	Content of JSON object:
		timestamp - Received timestamp from .bat file invoking this script.
		interface_settings_location - Network path for the interface root directory from received instance_path.
		DSN - Target instance; Read from General_Settings.ini
		config_struc_name - Wbs600 or other configuration structure; Read from General_Settings.ini
		pv_ws_username - Username for accessing Planview Web Services; Read encrypted from General_Settings.ini
		pv_ws_password - Password for accessing Planview Web Services; Read encrypted from General_Settings.ini
		organization - SnapLogic org; Read from General_Settings.ini
		project_space - SnapLogic customer project space; Read from General_Settings.ini
		project - SnapLogic customer interface project; Read from General_Settings.ini
		component_space - SnapLogic Project Space name where reusable components are available; Read from General_Settings.ini
		utility_project - SnapLogic project in component_space where utils component is present; Read from General_Settings.ini
		pve_dyn_sql_component_acc - Fully qualified SnapLogic SQL Server Dynamic account used for components; Read from General_Settings.ini
		pve_smtp_component_acc - Fully qualified SnapLogic SMTP account used for components; Read from General_Settings.ini
		asynchronous - Whether the task shall be started anynchronous or be monitored while running; Read from General_Settings.ini
		db_server - Read from dbconnection.ini
		db_path - Read from dbconnection.ini
		db_personality - Read from dbconnection.ini
		db_account - Read encrypted from dbconnection.ini
		db_password - Read encrypted from dbconnection.ini
		db_port - Read from General_Settings.ini
		db_SMTP_Server - Read from dbconnection.ini
		web_server - Read from dbconnection.ini
		web_base_path - Read from dbconnection.ini
		web_server_base_url - Read from dbconnection.ini
		content_store_path - Read from dbconnection.ini
		opensuite_interfaces_path - Read from dbconnection.ini
	Additional custom contents to read from general_settings.ini can be included using general_settings_param.

.DESCRIPTION
	The Read-Ini function extracts property values from ini files using PVAppSettingsManagement.AppSettings.
	The Invoke-SL function executes a task using URL with Basic Authentication.
	The Monitor-Task function monitors a task's state and returns once the state is not "Started" or "Prepared".

.PARAMETER instance_path

.PARAMETER general_settings_param
	Definition of custom values to be read from general_settings.ini and included in JSON Object passed to triggered task.
	A delimited string of format {{Read}|{Read encrypted}} where {Read} and {Read encrypted} are comma separated lists.
	Examples:
	"abc_url"				read abc_url normally.
	"|abc_password"				read encrypted abc_password.
	"abc_url,abc_user|abc_password"		read abc_url and abc_user normally and read encrypted abc_password.
	"abc_url|abc_password,abc_user"		read abc_url normally and read encrypted abc_password and abc_user.

.PARAMETER timestamp

.PARAMETER task
	Snaplogic triggered Task to be executed.
	If empty then task from general_settings.ini is used.
	If "Install-DB-Objects" then installation of database objects using DBANG and SQLCMD is executed.
	If "Install", then use the project/task in installation_task in component_space
	If "ConfigCheck", then use the project/task in configcheck_task in component_space 
	If "Logs2CMS", then use the project/task in logs2CMS_task in component_space 
	If task name provided then execute task in project_space from general_settings.ini
	If project/task provided then execute task in component_space from general_settings.ini (forward-slash / in argument)

.PARAMETER dbconnection_path
	The path where dbconnection.ini can be found.
	If empty path where AppSettingsManagement.dll is registered is used.

.NOTES
	Version:		3.5
	Author:			Markus Laun, Vince Rimkus
	Creation Date:	26 Jul 2022
	Purpose/Change:
	[11/23/2018 - Interface Team  v2.2]:
		Determine network path updated to use HostName
		1. Always read component_space from general_settings (no need to explicityly pass it as argument in general_settings_param)
		2. Always read opensuite_interfaces_path from dbconnection.ini
		3. If provided, get project from batch (args[3]=project/task) and execute given task in that project
	[4/29/2019 - Bert Jansen  v2.3]:
		1. Always read proxy from general_settings (new entry in general_settings)
		2. Function Invoke-SL - when connecting to https://elastic.snaplogic.com use proxy, else do not
	[6/12/2019 - Interface Team v2.4]:
		1. Read encrypted db_account, db_password are from dbconnection.ini to config parameters enc_db_account,enc_db_password	(for PVLoader support)
	[2/21/2020 - Markus Laun v2.5]:
		New Snaplogic monitoring response "NoUpdate". This status will now be interpreted as running interface and monitoring will continue.
	[3/20/2020 - Interface Team v2.6]:
		1. Always read db_port from general_settings (no need to explicitly pass it as argument) - Can be used when port number is different from default 1433
		2. If db_server is provided in general_settings, then read and use this to override db_server from dbconnection.ini - Can be used when database alias is used.
	[4/20/2020 - Interface Team v2.7]:
		1. Read encrypted db_query_account,db_query_password are from dbconnection.ini to config parameters db_query_account,db_query_password(for Reporting Purpose)
		2. Copy the json config to both config and appSettings object when invoking task
	[5/18/2020 - Interface Team v2.8]:
		1. Copy the json config only to config object when invoking task
	[2/10/2021 - Interface Team v2.9]:
		New Snaplogic monitoring response status 404.
		There is a latency between invocation of a task and the Snaplogic Pipeline Monitoring API becoming aware of the RUUID of the invoked pipeline.
		To give the lame machanism a little time to find itself, we introduce a delay.
		During this delay time this status will now be interpreted as running interface and monitoring will continue.
		The delay is 30 seconds.
	[2/16/2021 - Interface Team v2.10]:
		Bugfix: V2.9 does not delay for 30s.
		Invoke-Webrequest generates exceptions for 4xx http status codes.
		Features added in V2.9 now work as described.
	[2/26/2021 - Interface Team v2.11]:
		Bugfix: V2.10 does not catch the 404 Exception when proxy is set.
		Exception now handled correctly with proxy.
	[6/07/2021 - Interface Team v3.0]:
		1. Monitoring Stopwatch (35s), 5 retry attempts.
			This is to overcome the issue of hanging JobStream Jobs.
			When Snaplogic Monitoring API does not respond 5 times in a row within 35 seconds,
			then the script will exit with error and the Jobstream Job will fail.
		2. Support Cloud URL and On Premises Secure URL. $snaplogic['URL'] is generated depending on General_Settings.ini -> snaplogic_endpoint
			a. when Cloud URL use 					<endpoint>/api/1/rest/slsched/feed/<organization>/<project_space>/<project>/<task>
			b. when On Premises Secure URL use 		<endpoint>/api/1/rest/feed/<organization>/<project_space>/<project>/<task>
		3. Ensure 32bit execution context
	[6/15/2021 - Interface Team v3.1]:
        1. Bugfix: optional parameter intake from General_Settings.ini:
                api_timeout
                api_retry
           When parameters are undefined in General_Settings.ini then default api_timeout=35 and api_retry=5
        2. Suppress Error output when planviewresponse does not contain RUN_ID.
    [7/19/2021 - Interface Team v3.2]:
        1. Monitoring Snaplogic in single process to avoid hanging JobStreams.
		2. Introduction of 18h global timeout - script will stop after 18h runtime and signal error to JobStreamExecutionService.
		3. General code cleanup to align with best practises.
    [7/21/2021 - Interface Team v3.3]:
        1. Introduction of background jobs to avoid hanging JobStreams.
        2. Optional parameter intake from General_Settings.ini:
                monitorTimeout
           When parameter is undefined in General_Settings.ini then default monitorTimeout=64800 (64800 Seconds = 18 Hours).
    [10/18/2022 - Interface Team v3.5]: GIS Arch 2022 changes
        1. Always read organization, project_space, project, config_struc_name, utility_project, pve_dyn_sql_component_acc, pve_smtp_component_acc from General_Settings.ini
	2. Create genSettings as copy of config with minor difference and send both to url to ensure backward compatibility.
        3. Install, ConfigCheck and Logs2CMS tasks read from general_settings.ini.
#>
<#
    INITIIALIZATION
#>
#Ensure 32bit execution context
if ($env:Processor_Architecture -ne "x86")
{ write-warning 'Launching x86 PowerShell'
&"$env:windir\syswow64\windowspowershell\v1.0\powershell.exe" -noninteractive -noprofile -executionpolicy bypass -file $myinvocation.Mycommand.path $args[0] $args[1] $args[2] $args[3] $args[4]
exit
}
#Init
Write-Output ($args -join "`n")
Write-Output "args: $($args)"
Write-Output "instance_path: $($args[0])"
Write-Output "general_settings_param: $($args[1])"
Write-Output "timestamp: $($args[2])"
Write-Output "task: $($args[3])"
Write-Output "dbconnection_path: $($args[4])"
$instance_path = $args[0]
$general_settings_param = $args[1]
$timestamp = $args[2]
$task = $args[3]
$dbconnection_path = $args[4]
# GIS Arch 2022 changes - always read organization, project_space, project, config_struc_name, pve_dyn_sql_component_acc
$general_settings_read = @("config_struc_name","component_space","organization","project_space","project","utility_project","pve_dyn_sql_component_acc","pve_smtp_component_acc","asynchronous","db_port","api_timeout","api_retry","monitorTimeout")
$general_settings_readenc = @("pv_ws_username", "pv_ws_password")
$config = @{ }
$config['timestamp'] = $timestamp
$snaplogic = @{ }

#Determine network path
Get-WmiObject Win32_share | Where-Object {$_.Name -notlike "*$"} | Sort-Object { $_.Path.length} -Descending | Foreach-Object {
    If ($($instance_path) -like "$($_.Path)*"){
        $config['interface_settings_location'] = ("file:////$([System.Net.Dns]::GetHostByName("$($env:computername)").HostName)/$($instance_path)") -replace [RegEx]::Escape($($_.Path)),[RegEx]::Escape($($_.Name)) -replace [RegEx]::Escape("\"),"/"
        $config['interface_settings_location'] = $config['interface_settings_location'].trim("/")
		return
    }
}
If (([string]::IsNullOrEmpty($config['interface_settings_location']))) {
    Write-Output "`tError: $($instance_path) is not shared."
	Exit
}


$snaplogicHelpers = {
    if (-not ('TrustAllCertsPolicy' -as [type])) {
        Add-Type -TypeDefinition @"
        using System.Net;
        using System.Security.Cryptography.X509Certificates;
        public class TrustAllCertsPolicy : ICertificatePolicy {
            public bool CheckValidationResult(
                ServicePoint srvPoint, X509Certificate certificate,
                WebRequest request, int certificateProblem) {
                    return true;
            }
        }
"@

    }
    #trust all certificates
    [System.Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertsPolicy

    #TLS 1.2
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

    #Invoke-SL
    Function Invoke-SL
    {
        <#
        .SYNOPSIS
        Invoke a URI and provide response including time taken.
        .DESCRIPTION
        The Invoke-SL function executes a task using URL with Basic Authentication.
        .PARAMETER Url
        The Url to be invoked.
        .PARAMETER User
        The username to be used with Basic Authentication.
        .PARAMETER Password
        The password to be used with Basic Authentication.
        .PARAMETER Proxy
        Optional Proxy server to be used on connection.
        .NOTES
        Function returns an object with 2 members: response and time.
        #>
        [CmdletBinding()]
        Param (
            [string]$Url,
            [string]$User,
            [string]$Password,
            [string]$Proxy
        )
        Process
        {
            Write-Host "Invoke-SL incoming Url: $($Url -replace '^([^=]+=?).*', '$1')"
            #Write-Host "Invoke-SL incoming User: $User"
            #Write-Host "Invoke-SL incoming Password: $Password"
            Write-Host "Invoke-SL incoming Proxy: $Proxy"
            #Authentication
            $pair = "${User}:${Password}"
            $encodedCreds = [System.Convert]::ToBase64String([System.Text.Encoding]::ASCII.GetBytes($pair))
            $basicAuthValue = "Basic $encodedCreds"
            $Headers = @{ Authorization = $basicAuthValue }
            #Invoke
            if ($Url.StartsWith("https://elastic.snaplogic.com/api") -and (-not $Proxy.Equals(("")))) {
                    Write-Host "`tusing proxy."
            } else {
                    Write-Host "`tproxy bypassed."
            }
            #Invoke-WebRequest -UseBasicParsing -Uri "$Url" -Headers $Headers

            $time = try
            {
                $request = $null
                if ($Url.StartsWith("https://elastic.snaplogic.com/api") -and (-not $Proxy.Equals(("")))) {
                    $res1 = Measure-Command { $request = try { Invoke-WebRequest -UseBasicParsing -Uri "$Url" -Proxy "$Proxy" -Headers $Headers } catch [System.Net.WebException] { $_.Exception.Response } }
                } else {
                    $res1 = Measure-Command { $request = try { Invoke-WebRequest -UseBasicParsing -Uri "$Url" -Headers $Headers } catch [System.Net.WebException] { $_.Exception.Response } }
                }
                $res1.TotalSeconds
            }
            catch
            {
                $request = $_
                $time = -1
                Write-Host $_.ScriptStackTrace
                Write-Host $_.ErrorDetails
                Write-Host $_.Exception
            }
            #return result
            $out = "" | Select-Object -Property request, time
            $out.request = $request
            $out.time = $time
            return $out
        }
    }

    #Monitor-Task
    Function Monitor-Task
    {
        <#
        .SYNOPSIS
        Monitors a Snaplogic task using a RUUID. The state of the task is fetched in incementing frequency of 1-60 seconds.
        .DESCRIPTION
        The Monitor-Task function monitors a RUUID's state using Snaplogic Pipeline Monitoring API.
        .PARAMETER Org
        The Snaplogic Org the task was started within.
        .PARAMETER Ruuid
        The Snaplogic RUUID assigned when the task was started.
        .PARAMETER User
        The username to be used with Basic Authentication.
        .PARAMETER Password
        The password to be used with Basic Authentication.
        .PARAMETER sleep
        Delay in seconds before the next state is fetched.
        .PARAMETER Proxy
        Optional Proxy server to be used on connection.
        .NOTES
        Function exits cleanly or with error - indicating successful or failed run to JobStreamExecutionService.
        #>
        [CmdletBinding()]
        Param (
            [string]$Org,
            [string]$Ruuid,
            [string]$User,
            [string]$Password,
            [string]$SmtpServer,
            [string]$SmtpUser,
            [DateTime]$monitorStart,
            [int]$apiRetry = 5,
            [int]$apiTimeout = 35,
            [int]$sleep = 1,
            [string]$Proxy
        )
        Write-Output "Function Monitor-Task: $($Ruuid)"
        $timeSpan = New-TimeSpan -Seconds $apiTimeout
        $monitor_url = "https://elastic.snaplogic.com/api/1/rest/public/runtime/" + [uri]::EscapeDataString($Org) + "/" + [uri]::EscapeDataString($Ruuid)

        $retryAttempt = 1
        while ($true) {
            $stopWatch = [System.Diagnostics.Stopwatch]::StartNew()
            do
            {
                $monitor = Invoke-SL -Url "$monitor_url" -User $User -Password $Password -Proxy "$Proxy"
                # throttle API requests inside loop
                if (-not $monitor) { Start-Sleep -Seconds 1 }
            }
            until (($monitor) -or ($stopWatch.Elapsed -ge $timeSpan))
            $stopWatch.Stop()

            #### Validate acceptable response
            if (-not $monitor) {
                Write-Warning "`tMonitoring API did not provide valid response in $($stopWatch.Elapsed)s on attempt #$($retryAttempt)."
                If ($retryAttempt -gt $apiRetry) {
                    Write-Output "`tERROR: Monitoring failed. Retries exceeded"
                    Send-MailMessage -SmtpServer "$SmtpServer" -To gis-mon-powershell-er-aaaad3cohpisf5r4ombhnc56ke@planview.slack.com -From "$SmtpUser" -Subject "Monitoring failed: $monitor_url" -Body "Monitoring API did not respond in $($stopWatch.Elapsed) on attempt #$retryAttempt."
                    Exit 1
                }
                $retryAttempt++
                continue
            }

            switch ([int]$monitor.request.StatusCode)
            {
                200 {
                    $response = ConvertFrom-Json $monitor.request.Content
                    Write-Output "`t$(Get-Date -format 's') - $($response.response_map.state) (requestTime: $($monitor.time)s)"
                    If (@("Started", "Prepared", "NoUpdate") -contains $response.response_map.state)
                    {
                        #### Pipeline not finished yet
                        Start-Sleep -s $sleep
                        if ($sleep -lt 60) {
                            $sleep++
                        }
                    } else {
                        #### Pipeline has a final status
                        # Exit
                        Write-Output "Done."
                        return
                    }
                }
                401 {
                    Write-Output "`tError: Access denied."
                    Exit 1
                }
                404 {
                    # Delay 30s in case of 404 status
                    $duration = ((Get-Date)-$monitorStart).totalseconds
                    if ($duration -lt 30) {
                        Write-Output "`t$(Get-Date -format 's') - Waiting for Monitoring response...$($duration)s"
                        Start-Sleep -s $sleep
                    } else {
                        Write-Output "`tError: $($monitor)"
                        Exit 1
                    }
                }
                default
                {
                    Write-Output "`tError: $($monitor)"
                    Exit 1
                }
            }
        }
    }
}


#Read-Ini
Function Read-Ini
{
    <#
    .SYNOPSIS
    Read encrypted and non-encrypted property values from specified section of an ini file.
    .DESCRIPTION
    The Read-Ini function extracts property values from ini files using PVAppSettingsManagement.AppSettings.
    .PARAMETER out
    A hashtable (reference) where extracted key name:value pairs are added.
    .PARAMETER Path
    The path where  target ini can be found.
    .PARAMETER File
    The name of the ini file to be read.
    .PARAMETER Section
    The section to be read from.
    .PARAMETER Fields
    An array of keys to be read where value is not encrypted.
    .PARAMETER EncFields
    An array of keys to be read where value is encrypted.
    .NOTES
    Key:Value pairs will be added to $out.
    #>
    [CmdletBinding()]
    Param (
        [hashtable]$out = @{ },
        [string]$Path,
        [string]$File,
        [string]$Section,
        [string[]]$Fields = @(),
        [string[]]$EncFields = @()
    )
    Process
    {
        $Path = [System.IO.Path]::GetFullPath($Path)
        if (!(Test-Path -Path "$Path"))
        {
            Write-Output "`tError: Path $Path could not be found."
            Break
        }
        if (!(Test-Path -Path "$Path$File.ini" -PathType leaf))
        {
            Write-Output "`tError: File $Path$File.ini could not be found."
            Break
        }
        Write-Output "Reading $Path$File.ini [$Section]"
        $a = new-object -com PVAppSettingsManagement.AppSettings
        $a.SetBasePath($Path)
        $a.Open($File)
        Try
        {
            $a.Open($Section)
        }
        Catch
        {
            Write-Output "`tError: Section $Section could not be found."
            Break
        }
        foreach ($f in $Fields.GetEnumerator())
        {
            $out[$f] = $a.Read($f)
            Write-Output "`t${f}: $($out[$f])"
        }
        foreach ($f in $EncFields.GetEnumerator())
        {
            $out[$f] = $a.ReadEncrypted($f)
            Write-Output "`t${f}: *****"
        }
        $a.Close()
        [System.Runtime.Interopservices.Marshal]::ReleaseComObject($a) | out-null
        Remove-Variable a
    }
}


<#
    MAIN
#>
#Merge general_settings parameter
$gs_parts = $general_settings_param.split([RegEx]::Escape("|"))
If (@($gs_parts).length -gt 0) { $gs_parts[0].split(",") | ForEach-Object { $general_settings_read += $_ } }
If (@($gs_parts).length -gt 1) { $gs_parts[1].split(",") | ForEach-Object { $general_settings_readenc += $_ } }
$general_settings_read = $general_settings_read | Select-Object -uniq | Where-Object {$_}
$general_settings_readenc = $general_settings_readenc | Select-Object -uniq | Where-Object {$_}

#General_Settings.ini
Read-Ini -out ([ref]$config) -Path "$instance_path" -File "General_Settings" -Section "TARGET" -Fields @("DSN")
IF ([string]::IsNullOrEmpty($config['DSN']))
{
    Write-Output "`tError: Target DSN is not defined."
    Exit
}
else
{
    $DSN = $($config['DSN'])
}
Read-Ini -out ([ref]$config) -Path "$instance_path" -File "General_Settings" -Section "$DSN" -Fields $general_settings_read -EncFields $general_settings_readenc

$config['api_timeout'] = If (($null -eq ($config['api_timeout'] -as [int])) -or (($config['api_timeout'] -as [int]) -eq 0) -or ($null -eq $config['api_timeout'])) {35} else {($config['api_timeout'] -as [int])}
$config['api_retry'] = If (($null -eq ($config['api_retry'] -as [int])) -or (($config['api_retry'] -as [int]) -eq 0) -or ($null -eq $config['api_retry'])) {5} else {($config['api_retry'] -as [int])}
$config['monitorTimeout'] = If (($null -eq ($config['monitorTimeout'] -as [int])) -or (($config['monitorTimeout'] -as [int]) -eq 0) -or ($null -eq $config['monitorTimeout'])) {64800} else {($config['monitorTimeout'] -as [int])}
Write-Output "`tapi_timeout: $($config['api_timeout'])."
Write-Output "`tapi_retry: $($config['api_retry'])."
Write-Output "`tmonitorTimeout: $($config['monitorTimeout'])."

#dbconnection.ini
If (([string]::IsNullOrEmpty($dbconnection_path))) {
    $dbconnection_path = (Get-ItemProperty -Path "Registry::HKEY_CLASSES_ROOT\Wow6432Node\CLSID\{EA1A8741-11EF-11D3-9EAD-00A0C99C7A15}\InprocServer32").'(default)'
    If (([string]::IsNullOrEmpty($dbconnection_path))) {
        Write-Output "`tError: dbconnection.ini path could not be determined."
        Exit
    } Else {
        $dbconnection_path = $dbconnection_path.Substring(0, $dbconnection_path.lastIndexOf('\')+1)
    }
}
#2.4 change
Read-Ini -out ([ref]$config) -Path "$dbconnection_path" -File "dbconnection" -Section $DSN -Fields @("db_account", "db_password")
$config['enc_db_account'] = $config['db_account']
$config['enc_db_password'] = $config['db_password']
#2.6 Change Set db_server from general_settings file parameterif provided
#2.7 Change Read db_query user or pwd details

If ( ([string]::IsNullOrEmpty($config['db_server'])) ) {
    Read-Ini -out ([ref]$config) -Path "$dbconnection_path" -File "dbconnection" -Section $DSN -Fields @("db_server","db_path", "db_personality", "web_server", "web_base_path", "web_server_base_url", "db_SMTP_Server", "db_bulk_email", "content_store_path", "opensuite_interfaces_path") -EncFields @("db_account", "db_password","db_query_account","db_query_password")
} Else {
    Read-Ini -out ([ref]$config) -Path "$instance_path" -File "General_Settings" -Section $DSN -Fields @("db_server")
    Read-Ini -out ([ref]$config) -Path "$dbconnection_path" -File "dbconnection" -Section $DSN -Fields @("db_path", "db_personality", "web_server", "web_base_path", "web_server_base_url", "db_SMTP_Server", "db_bulk_email", "content_store_path", "opensuite_interfaces_path") -EncFields @("db_account", "db_password","db_query_account","db_query_password")
}

#Task
If (-not ([string]::IsNullOrEmpty($task))) {
    Write-Output "`t$task is not NullOrEmpty: $($task)"
    If ($task -eq "Install-DB-Objects") {
        #Install-DB-Objects
        Write-Output "Install-DB-Objects"
        $install_path = "$($instance_path)5_Install\"
        Push-Location $install_path
        Write-Output "`tPath: $(Get-Location)"
        Get-ChildItem $install_path -Filter *.sql | Sort-Object { $_.Name} |
        Foreach-Object {
            $dbang_args = @("$($_.Name)", "$($DSN)", "$($config['db_account'])", "$($config['db_password'])", "$($config['db_path'])")
            $sqlcmd_args = @("$($config['db_server'])", "$($_.Name)", "$($DSN)", "$($config['db_account'])", "$($config['db_password'])")
            If ($($_.Name) -like '*_DBANG_*') {
                #Execute DBANG
                $script_start = Get-Date
                Write-Output "`t(DBANG)  $($dbang_args[0]) $($dbang_args[1]) ... "
                Start-Process -FilePath 'cmd' -ArgumentList "/c echo **************************************************************************************************** `>`>$($instance_path)2_Logs\Install-DB-Objects_DBANG_$($timestamp).log 2`>`&1" -Wait -Passthru -WindowStyle Hidden | Wait-Process
                Start-Process -FilePath 'cmd' -ArgumentList "/c echo * dbang.exe $($dbang_args[0]) DSN=$($dbang_args[1]) ACC=$($dbang_args[2]) PWD=****** DBPATH=$($dbang_args[4]) `>`>$($instance_path)2_Logs\Install-DB-Objects_DBANG_$($timestamp).log 2`>`&1" -Wait -Passthru -WindowStyle Hidden | Wait-Process
                Start-Process -FilePath 'cmd' -ArgumentList "/c echo **************************************************************************************************** `>`>$($instance_path)2_Logs\Install-DB-Objects_DBANG_$($timestamp).log 2`>`&1" -Wait -Passthru -WindowStyle Hidden | Wait-Process
                Start-Process -FilePath 'cmd' -ArgumentList "/c dbang.exe $($dbang_args[0]) DSN=$($dbang_args[1]) ACC=$($dbang_args[2]) PWD=$($dbang_args[3]) DBPATH=$($dbang_args[4]) `>`>$($instance_path)2_Logs\Install-DB-Objects_DBANG_$($timestamp).log 2`>`&1" -Wait -Passthru -WindowStyle Hidden | Wait-Process
                $script_end = Get-Date
                $script_time = $script_end - $script_start
                Write-Output `($($script_time.ToString("mm\:ss\.fff"))`)`r
            } ElseIf ($($_.Name) -like '*_SQLCMD_*') {
                #Execute SQLCMD
                $script_start = Get-Date
                Write-Output "`t(SQLCMD) $($sqlcmd_args[1]) $($sqlcmd_args[0]) $($sqlcmd_args[2]) ... "
                Start-Process -FilePath 'cmd' -ArgumentList "/c echo **************************************************************************************************** `>`>$($instance_path)2_Logs\Install-DB-Objects_SQLCMD_$($timestamp).log 2`>`&1" -Wait -Passthru -WindowStyle Hidden | Wait-Process
                Start-Process -FilePath 'cmd' -ArgumentList "/c echo * sqlcmd -S $($sqlcmd_args[0]) -i $($sqlcmd_args[1]) -d $($sqlcmd_args[2]) -U $($sqlcmd_args[3]) -P ****** `>`>$($instance_path)2_Logs\Install-DB-Objects_SQLCMD_$($timestamp).log 2`>`&1" -Wait -Passthru -WindowStyle Hidden | Wait-Process
                Start-Process -FilePath 'cmd' -ArgumentList "/c echo **************************************************************************************************** `>`>$($instance_path)2_Logs\Install-DB-Objects_SQLCMD_$($timestamp).log 2`>`&1" -Wait -Passthru -WindowStyle Hidden | Wait-Process
                Start-Process -FilePath 'cmd' -ArgumentList "/c sqlcmd -S $($sqlcmd_args[0]) -i $($sqlcmd_args[1]) -d $($sqlcmd_args[2]) -U $($sqlcmd_args[3]) -P $($sqlcmd_args[4]) `>`>$($instance_path)2_Logs\Install-DB-Objects_SQLCMD_$($timestamp).log 2`>`&1" -Wait -Passthru -WindowStyle Hidden | Wait-Process
                $script_end = Get-Date
                $script_time = $script_end - $script_start
                Write-Output `($($script_time.ToString("mm\:ss\.fff"))`)`r
            }
        }
        Pop-Location
        Exit
    } ElseIf ($task -eq "Install") {
		#GIS Arch 2022 changes - added section
        Write-Output "`tSet Install Task from general settings parameter"
		#Task is installation task and should be picked from value provided in general settings parameter and should run in component_space
            Read-Ini -out ([ref]$snaplogic) -Path "$instance_path" -File "General_Settings" -Section $DSN -Fields @("snaplogic_endpoint", "organization", "component_space", "installation_task", "proxy") -EncFields @("snaplogic_user", "snaplogic_password")
			#Set component space
            $snaplogic['project_space'] = $snaplogic['component_space']
            $pos = $snaplogic['installation_task'].IndexOf('/')
            #Parse project
            $snaplogic['project'] = $snaplogic['installation_task'].Substring(0, $pos)
            #Parse task
            $snaplogic['task'] = $snaplogic['installation_task'].Substring($pos+1)
	} ElseIf ($task -eq "ConfigCheck") {
		#GIS Arch 2022 changes - added section
        Write-Output "`tSet Configuration Check Task from general settings parameter"
		#Task is configcheck task and should be picked from value provided in general settings parameter and should run in component_space
            Read-Ini -out ([ref]$snaplogic) -Path "$instance_path" -File "General_Settings" -Section $DSN -Fields @("snaplogic_endpoint", "organization", "component_space", "configcheck_task", "proxy") -EncFields @("snaplogic_user", "snaplogic_password")
			#Set component space
            $snaplogic['project_space'] = $snaplogic['component_space']
            $pos = $snaplogic['configcheck_task'].IndexOf('/')
            #Parse project
            $snaplogic['project'] = $snaplogic['configcheck_task'].Substring(0, $pos)
            #Parse task
            $snaplogic['task'] = $snaplogic['configcheck_task'].Substring($pos+1)
	} ElseIf ($task -eq "Logs2CMS") {
		#GIS Arch 2022 changes - added section
        Write-Output "`tSet Logs2CMS Task from general settings parameter"
		#Task is logs2cms task and should be picked from value provided in general settings parameter and should run in component_space
            Read-Ini -out ([ref]$snaplogic) -Path "$instance_path" -File "General_Settings" -Section $DSN -Fields @("snaplogic_endpoint", "organization", "component_space", "logs2cms_task", "proxy") -EncFields @("snaplogic_user", "snaplogic_password")
			#Set component space
            $snaplogic['project_space'] = $snaplogic['component_space']
            $pos = $snaplogic['logs2cms_task'].IndexOf('/')
            #Parse project
            $snaplogic['project'] = $snaplogic['logs2cms_task'].Substring(0, $pos)
            #Parse task
            $snaplogic['task'] = $snaplogic['logs2cms_task'].Substring($pos+1)
	} Else {
        Write-Output "`tSet Task from batch file parameter $($task)"
        #Set Task from batch file parameter
        If ($task -match '/') {
            Write-Output "`tTask is a component task and should run in component_space: $($task)"
            #Task is a component task and should run in component_space. The project is provided in the argument
            Read-Ini -out ([ref]$snaplogic) -Path "$instance_path" -File "General_Settings" -Section $DSN -Fields @("snaplogic_endpoint", "organization", "component_space", "project", "proxy") -EncFields @("snaplogic_user", "snaplogic_password")
			#Set component space
            $snaplogic['project_space'] = $snaplogic['component_space']
            $pos = $task.IndexOf('/')
            #Parse project
            $snaplogic['project'] = $task.Substring(0, $pos)
            #Parse task
            $snaplogic['task'] = $task.Substring($pos+1)
        }
        Else {
            Write-Output "`tTask is an interface task and should run in project_space: $($task)"
            #Task is an interface task and should run in project_space
            Read-Ini -out ([ref]$snaplogic) -Path "$instance_path" -File "General_Settings" -Section $DSN -Fields @("snaplogic_endpoint", "organization", "project_space", "project", "proxy") -EncFields @("snaplogic_user", "snaplogic_password")
            $snaplogic['task'] = $task
        }
        Write-Output "Setting Task from batch file parameter"
        Write-Output "`ttask: $($task) -> $($snaplogic['task'])"
    }
} Else {
    Read-Ini -out ([ref]$snaplogic) -Path "$instance_path" -File "General_Settings" -Section $DSN -Fields @("snaplogic_endpoint", "organization", "project_space", "project", "task", "proxy") -EncFields @("snaplogic_user", "snaplogic_password")
}
$snaplogic['URL'] = "$($snaplogic['snaplogic_endpoint'])"
If ($snaplogic['URL'].StartsWith("https://elastic.snaplogic.com")) {
    $snaplogic['URL'] += "/api/1/rest/slsched/feed/"
} else {
    $snaplogic['URL'] += "/api/1/rest/feed/"
}
$snaplogic['URL'] += [uri]::EscapeDataString($($snaplogic['organization'])) + "/" + [uri]::EscapeDataString($($snaplogic['project_space'])) + "/" + [uri]::EscapeDataString($($snaplogic['project'])) + "/" + [uri]::EscapeDataString($($snaplogic['task']))

#JSON payload
$json_config = convertto-json $config
$json_config = $json_config -replace "(\s)(?=(?:[^""] | ""[^""]*"")*$)", "" #removing all whitespace characters except from names and values
$json_config = [uri]::EscapeDataString($json_config)

#GIS Arch 2022 changes - create genSettings
$genSettings = $config
$genSettings['db_path'] += '.' #genSettings will return db_path including trailing period
$json_genSettings = convertto-json $genSettings
$json_genSettings = $json_genSettings -replace "(\s)(?=(?:[^""] | ""[^""]*"")*$)", "" #removing all whitespace characters except from names and values
$json_genSettings = [uri]::EscapeDataString($json_genSettings)


# Import Snaplogic Helpers into current scope
. $snaplogicHelpers

#Invoke Task
Write-Output "Invoking: $($snaplogic['URL'])"

#GIS Arch 2022 changes - genSettings added to url
$invokeParams = @{
    Url      = "$($snaplogic['URL'])?config=$json_config&genSettings=$json_genSettings" 
    User     = "$($snaplogic['snaplogic_user'])"
    Password = "$($snaplogic['snaplogic_password'])"
    Proxy    = "$($snaplogic['proxy'])"
}

Write-Output "invokeAction started...Invoke-SL $($invokeParams.GetEnumerator() | Where-Object { $_.Key -notin ('User', 'SmtpUser', 'Password') } | Out-String)"
$task = Invoke-SL @invokeParams
Write-Output "received status code $([int]$task.request.StatusCode)"
#Process Invocation
$shouldMonitor = $false
switch ([int]$task.request.StatusCode)
{
    200 {
        Write-Output "`tTask successfully invoked in $($task.time) seconds."
        $response = ConvertFrom-Json $task.request.Content
        IF ($($response.planviewresponse.error))
        {
            Write-Output "`Error:"
            #### TODO: should Error requests be monitored?
        }
        Write-Output "`t$($response.planviewresponse)"
        $ruuid = $response.planviewresponse.task_ruuid
        #Monitoring
        Write-Output "config[asynchronous]: $($config['asynchronous'])"
        If ("$($config['asynchronous'])" -eq "false")
        {
            Write-Output "Started synchronously, status will be monitored."
            $shouldMonitor = $true
        }
        else
        {
            Write-Output "Started asynchronously."
        }
    }
    401 {
        Write-Output "`tError: Access denied."
        Exit
    }
    409 {
        Write-Output "`tError: Task already running."
        Exit
    }
    default
    {
        Write-Output "`tError: $($task)"
        Exit
    }
}

<#
    Monitoring
#>
if ($shouldMonitor) {
    $monitorStart = Get-Date
    Write-Output "Start Monitoring [$($monitorStart)]: $($ruuid)"
    # Monitor PSJob details
    $monitorJobArgList = @(
        $config,
        $snaplogic,
        $ruuid,
        $monitorStart
    )
    $monitorAction = {
        param ([hashtable] $Config, [hashtable] $Snaplogic, [string] $Ruuid, [datetime] $MonitorStart)
        $monitorParams = @{
            Ruuid        = $Ruuid
            Org          = $snaplogic['organization']
            User         = $snaplogic['snaplogic_user']
            Password     = $snaplogic['snaplogic_password']
            Proxy        = $snaplogic['proxy']
            SmtpServer   = $config['db_SMTP_Server']
            SmtpUser     = $config['db_bulk_email']
            apiTimeout   = $config['api_timeout']
            apiRetry     = $config['api_retry']
            monitorStart = $MonitorStart
        }
        Write-Output "Start Monitoring: Monitor-Task $($monitorParams.GetEnumerator() | Where-Object { $_.Key -notin ('User', 'SmtpUser', 'Password') } | Out-String)"
        Monitor-Task @monitorParams
    }
    $monitorJob = Start-Job -ScriptBlock $monitorAction -InitializationScript $snaplogicHelpers -ArgumentList $monitorJobArgList

    $monitorCnt = 0
    $monitorWatch = [System.Diagnostics.Stopwatch]::StartNew()
    $monitorTimespan = New-Timespan -Seconds $config['monitorTimeout'] # 64800
    Write-Output "Job will monitor for $($config['monitorTimeout'])s"

    $pollWatch = [System.Diagnostics.Stopwatch]::StartNew()
    $pollTimespan = New-Timespan -Seconds 90 #### TODO: Move to config?

    # Main Monitor Loop
    while ($true) {
        if ($monitorWatch.Elapsed -ge $monitorTimespan) {
            Write-Warning "Maximum runtime exceeded. Terminating Execution after $($monitorWatch.Elapsed)"
            exit -1
        }

        if ($pollWatch.Elapsed -ge $pollTimespan) {
            #### poll timer has not been reset, no data has been received in $pollTimespan seconds
            #### increment $monitorCnt and re-run job
            $monitorCnt++
            $monitorJob | Receive-Job
            $monitorJob | Remove-Job -Force
            If ($monitorCnt -ge $config['api_retry']) {
                Write-Warning "Timeout exceeded for Monitor-Task. Duration [$($pollWatch.Elapsed)] -> Terminating execution on attempt $($monitorCnt)/$($config['api_retry'])."
                Send-MailMessage -SmtpServer "$($config['db_SMTP_Server'])" -To gis-mon-powershell-er-aaaad3cohpisf5r4ombhnc56ke@planview.slack.com -From "$($config['db_bulk_email'])" -Subject "Monitoring TIMEOUT!" -Body "Monitoring API timed out after $($pollWatch.Elapsed)`r$("$($snaplogic['URL'])?config=$json_config")"
                exit -1
            }
            Write-Warning "Timeout exceeded for Monitor-Task. Duration [$($pollWatch.Elapsed)] -> Retry attempt $($monitorCnt)/$($config['api_retry'])"
            Start-Sleep -Seconds 10
            $monitorJob = Start-Job -ScriptBlock $monitorAction -InitializationScript $snaplogicHelpers -ArgumentList $monitorJobArgList
            #### Restart timer, so the new job has 90 seconds as well.
            $pollWatch.Restart()
        }
        if ($monitorJob.State -ne 'Running') {
            ### Job has final state
            $monitorJob | Receive-Job
            break
        }
        else {
            $currentResponse = $monitorJob | Receive-Job
            If ($null -ne $currentResponse) {
                #### Received output from monitor job, display and reset timer
                Write-Output "$($currentResponse)"
                $pollWatch.Restart()
            }
        }
        Start-Sleep -Milliseconds 500
    }
}
